<?php
$conn = new PDO('mysql:host=127.0.0.1;dbname=ndusys0_student','ndusys0_student','Harder01!');
//$conn = new PDO('mysql:host=localhost;dbname=studentdb','root','');
?>